
This folder contains language files that have been
removed from the installer package because they have not
updated for a very long time.

You can still use these files but most of the text might
be displayed in english.

Please feel free to update these files. It would be nice
if you could send me your work in order to make it available
for other users.
